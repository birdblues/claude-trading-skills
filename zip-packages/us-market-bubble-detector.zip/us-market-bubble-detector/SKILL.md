---
name: us-market-bubble-detector
description: Evaluates US stock market bubble risk through crowd psychology and social contagion using the Minsky/Kindleberger framework. Supports practical investment decisions (profit-taking, risk management, short timing). Use when user asks about market euphoria, bubble risk, valuation concerns, profit-taking timing, or observes social phenomena like "taxi drivers giving stock tips" or "everyone talking about stocks". 米国株式市場のバブル度を群集心理・社会的伝播から評価し、実務的投資判断を支援。市場の熱狂度、バブルリスク、利確タイミング、空売り判断を尋ねられた時や、非投資家の参入等の社会現象観察時に使用。
---

# 米国市場バブル判定スキル

## 概要

このスキルは、米国株式市場のバブル度を**価格水準ではなく群集心理の位相**で判定し、実務的な投資アクションを提案します。

### コアコンセプト / Core Concept

真のバブルは以下の3つの条件で完成します / A true bubble is complete when these 3 conditions are met:

1. **情報カスケードの臨界到達 / Critical Information Cascade** - あらゆる層（非投資家含む）への波及完了 / Spread to all layers (including non-investors) is complete
2. **社会的規範の転倒 / Social Norm Inversion** - 「同調しない痛み > 独立判断の価値」/ "Pain of non-conformity > Value of independent judgment"
3. **FOMOの制度化 / Institutionalized FOMO** - 懐疑派でいることの社会的コストが最大化 / Social cost of skepticism is maximized

**象徴的シグナル / Iconic Signal:** タクシー運転手や家族が投資を推奨し始めたら、最後の買い手層の参入を意味し、バブル完成間近。/ When taxi drivers or family members start recommending investments, it signals the "last buyer" cohort has entered—bubble completion is near.

## 使用タイミング / When to Use This Skill

以下のような状況で本スキルを使用してください / Use this skill when:

**日本語:**
- ユーザーが「今の相場はバブルか?」と尋ねる
- 投資の利確・新規参入・空売りのタイミング判断を求める
- 社会現象（非投資家の参入、メディア過熱、IPO氾濫）を観察し懸念を表明
- 「今回は違う」「革命的技術」などの物語が主流化している状況を報告
- 保有ポジションのリスク管理方法を相談

**English:**
- User asks "Is the market in a bubble?" or "Are we in a bubble?"
- User seeks advice on profit-taking, new entry timing, or short-selling decisions
- User reports social phenomena (non-investors entering, media frenzy, IPO flood)
- User mentions narratives like "this time is different" or "revolutionary technology" becoming mainstream
- User consults about risk management for existing positions
- User observes taxi drivers, family members, or other non-investors recommending stocks

## ワークフロー

### Step 1: Bubble-O-Meterによる定量評価

8つの指標を0-2点で評価し、合計スコア（0-16点）でバブル度を判定します。

#### 8つの指標

1. **大衆浸透度** - 非投資家層（タクシー運転手、美容師、家族）からの推奨・言及
2. **メディア飽和** - 検索トレンド、SNS、テレビ報道の急騰
3. **新規参入** - 口座開設、資金流入の加速
4. **新規発行氾濫** - IPO/SPAC/関連ETFの乱立
5. **レバレッジ** - 証拠金残高、信用評価損益、資金調達レートの偏り
6. **価格加速度** - リターンが歴史分布の上位百分位に到達
7. **バリュエーション逸脱** - ファンダメンタル説明が「物語」一辺倒に
8. **相関と幅** - 低質銘柄まで全面高（最後の買い手参入のサイン）

#### スコアリング方法

対話形式で各指標を評価するか、ユーザーから提供された市場観察情報に基づいて評価します。

```bash
# スクリプトによる評価（対話式）
python scripts/bubble_scorer.py --manual

# スコアを直接指定
python scripts/bubble_scorer.py --scores '{"mass_penetration":2,"media_saturation":1,...}'
```

#### 判定基準

| スコア範囲 | フェーズ | リスクレベル | 推奨アクション |
|-----------|---------|------------|--------------|
| 0-4点 | 正常域 | 低 | 通常通りの投資戦略を継続 |
| 5-8点 | 警戒域 | 中 | 部分利確開始、新規ポジション縮小 |
| 9-12点 | 熱狂域 | 高 | 階段状利確加速、総リスク予算30-50%削減 |
| 13-16点 | 臨界域 | 極めて高 | 大幅利確またはフルヘッジ、反転後ショート検討 |

### Step 2: Minsky/Kindlebergerフェーズの特定

スコアと市場観察から、バブルの進行段階を特定します:

1. **Displacement（きっかけ）** - 新技術・制度変化・金融緩和
2. **Boom（拡張）** - 価格上昇の自己強化ループ
3. **Euphoria（熱狂）** - FOMOが社会規範化、レバレッジ増加
4. **Profit Taking（利確開始）** - スマートマネーの撤退開始
5. **Panic（反転）** - 清算の連鎖

詳細な段階別特徴は `references/bubble_framework.md` を参照してください。

### Step 3: 実務アクションの提案

バブル段階に応じた具体的な投資アクションを提案します。

#### 攻め：利確戦略

**階段状利確（推奨）:**
```
目標リターン    利確割合
+20%           25%
+40%           25%
+60%           25%
+80%           25%
```

**ATRトレーリングストップ（攻撃的）:**
```python
stop_price = current_price - (ATR_20日 × 係数)
# 係数: 2.0（正常）、1.8（警戒）、1.5（熱狂）、1.2（臨界）
```

#### 守り：リスク管理

**バブル段階別リスク予算:**
- 正常域: 100%（フルポジション可）
- 警戒域: 70%（30%削減）
- 熱狂域: 40%（60%削減）
- 臨界域: 20%以下（大幅削減）

**空売りタイミング（重要）:**

❌ 絶対NG: 早期逆張り（「高すぎる」という主観判断）

✅ 推奨: 複合条件確認後（最低3つ該当）
1. 週足で高値切り下げ
2. 出来高ピークアウト
3. レバレッジ指標急低下
4. メディア・検索トレンドピークアウト
5. 弱い銘柄から崩れ始める
6. VIX急騰
7. FRB等の政策転換シグナル

### Step 4: 継続モニタリングの設計

日次チェックリストを提供します:

**朝のルーティン（5分）:**
1. Bubble-O-Meter更新（8指標スコアリング）
2. ATRトレーリングストップ更新
3. シグナル確認（Google Trends、VIX、Put/Call比率）

詳細は `references/quick_reference.md` を参照してください。

## リソース活用ガイド

### スクリプト

**`scripts/bubble_scorer.py`**
- Bubble-O-Meterの計算スクリプト
- 対話式評価またはJSON入力に対応
- 総合スコア、Minskyフェーズ、推奨アクションを出力

### リファレンス / References

**`references/bubble_framework.md`** (日本語)
- 理論的フレームワークの詳細
- Minsky/Kindlebergerモデルの解説
- 行動心理学の要素
- 検知のための定量指標
- 実務対応戦略の詳細

**`references/historical_cases.md`** (日本語)
- 過去のバブル事例分析
  - 1990年代ドットコムバブル
  - 2017年暗号資産バブル
  - 2020-21年パンデミックバブル
- 共通パターンの抽出
- ケーススタディと教訓

**`references/quick_reference.md`** (日本語)
- 日次チェックリスト
- 緊急判定の3つの質問
- スコアリング簡易版
- 主要データソース
- よくある失敗パターンと対策

**`references/quick_reference_en.md`** (English)
- Daily checklist
- Emergency 3-question assessment
- Quick scoring guide
- Key data sources
- Common failure patterns & solutions

### リファレンス読み込みタイミング / When to Load References

- **初回使用時 / First use:** `bubble_framework.md` を読み込んで理論を理解 / Load to understand theory
- **過去事例の参照が必要 / Need historical context:** `historical_cases.md` を読み込み / Load for case studies
- **日次運用 / Daily operations:** 
  - 日本語: `quick_reference.md` 
  - English: `quick_reference_en.md`
- **詳細な判定基準が必要 / Need detailed criteria:** 該当するリファレンスの該当セクションを読み込み / Load relevant reference sections

## 出力形式

### 評価レポート構成

```markdown
# 米国市場バブル度評価レポート

## 総合評価
- 総合スコア: X/16点 (Y%)
- 市場フェーズ: [正常域/警戒域/熱狂域/臨界域]
- Minskyフェーズ: [該当フェーズ]
- リスクレベル: [低/中/高/極めて高]

## 指標別詳細
[8指標のスコアと根拠]

## 推奨アクション

### 即座に実行すべきこと
[具体的なアクション]

### リスク管理
[ポジションサイジング、ストップ設定]

### 空売り検討
[条件確認と判断]

## 継続モニタリング
[日次チェック項目]

## 警告シグナル
[注意すべき兆候]
```

## 重要な原則

### 1. 価格水準ではなく心理プロセスを見る

「高すぎる」という主観ではなく、群集心理の位相転換（情報カスケード、社会規範の転倒、FOMOの制度化）を客観的に評価します。

### 2. 機械的ルールが心を守る

バブル期は同調圧力が最大化し、合理的判断が困難になります。事前に決定したルール（階段状利確、ATRトレーリング）を厳守することで、心理的圧力に負けない投資を実現します。

### 3. 完璧を捨てて満足を目指す

ピークで売ることは不可能です。階段状利確で「確実に利益確保」を優先し、「もっと儲かったのに」という後悔を管理します。

### 4. 早すぎる逆張りは危険

「明らかに高すぎる」と感じてからさらに2-3倍上昇することは普通です。空売りは複合条件の客観的確認後のみ検討します。

## よくある質問

**Q: スコアが警戒域だが、まだ上がりそうな場合は?**
A: バブルは「思ったより長く続く」のが常です。警戒域では部分利確とポジション縮小を開始し、残りはATRトレーリングで上昇を追随しながらリスクを管理します。

**Q: 過去のバブルとの比較は有効か?**
A: はい。Minsky/Kindlebergerモデルは多くのバブルに共通するパターンです。`references/historical_cases.md` で過去事例との比較を参照してください。

**Q: 日々の小さな変動に過剰反応すべき?**
A: いいえ。Bubble-O-Meterは週次または重要イベント後の更新で十分です。日次では価格のATRトレーリングストップ更新と主要シグナル（VIX、トレンド）確認のみ実施します。

**Q: AI・暗号資産など新技術の「今回は違う」は本当では?**
A: 技術革新は本物でも、バブル化は別問題です。革命的技術でも価格は行き過ぎます。ドットコムバブルのインターネットも本物の革命でしたが、2000年の価格は明らかに行き過ぎでした。

## 使用例 / Usage Examples

### 例1 / Example 1: ユーザーが社会現象を報告 / User Reports Social Phenomena

**日本語:**
**ユーザー:** 「最近、職場の同僚全員がNVIDIA株の話をしていて、投資経験のない人まで『絶対買うべき』と言っています。これってバブルですか?」

**English:**
**User:** "Recently, everyone at work is talking about NVIDIA stock, and even people with no investment experience are saying 'you absolutely must buy.' Is this a bubble?"

**対応 / Response:**
1. Bubble-O-Meterの「大衆浸透度」を評価（スコア1-2の可能性）/ Evaluate "Mass Penetration" indicator (likely score 1-2)
2. 他の7指標も対話で確認 / Confirm other 7 indicators through dialogue
3. 総合スコアに基づいた判定とアクション提案 / Provide judgment and action recommendations based on total score
4. 「タクシー運転手の法則」の文脈で説明 / Explain in context of "Taxi Driver Rule"

### 例2 / Example 2: ユーザーが利確タイミングを相談 / User Seeks Profit-Taking Advice

**日本語:**
**ユーザー:** 「ポジションが+60%になりましたが、まだ上がりそうです。売るべきでしょうか?」

**English:**
**User:** "My position is up 60%, but it seems like it will go higher. Should I sell?"

**対応 / Response:**
1. 現在のBubble-O-Meterスコアを評価 / Evaluate current Bubble-O-Meter score
2. 階段状利確ルールに基づいた提案（+60%で25%利確）/ Suggest stair-step profit-taking rule (25% at +60%)
3. 残りポジションのATRトレーリングストップ設定 / Set ATR trailing stop for remaining position
4. 「満足を目指す」原則の説明 / Explain "aim for satisfaction" principle

### 例3 / Example 3: ユーザーが空売りを検討 / User Considers Short Selling

**日本語:**
**ユーザー:** 「明らかに高すぎる気がします。空売りすべきですか?」

**English:**
**User:** "It seems obviously too high. Should I short?"

**対応 / Response:**
1. ⚠️ 早期逆張りのリスクを警告 / Warn of early contrarian risks
2. 空売り複合条件（7項目）の確認 / Check short-selling composite conditions (7 items)
3. 最低3項目該当するまで待機を推奨 / Recommend waiting until at least 3 conditions are met
4. 該当する場合は小ロット（通常の25%）でのテスト参入提案 / If conditions met, suggest small position (25% of normal) test entry

## 結論 / Conclusion

**日本語:**
このスキルは、バブルを「価格水準」ではなく「群集心理の位相」で判定し、機械的ルールによる実務的な投資判断を支援します。

**English:**
This skill evaluates bubbles through "crowd psychology phase" rather than "price level," supporting practical investment decisions through mechanical rules.

**キーメッセージ / Key Messages:**
- タクシー運転手が語り出したら手仕舞え / When taxi drivers talk stocks, exit
- 機械的ルールが心を守る / Mechanical rules protect psychology
- 空売りは確認後、利確は早めに / Short after confirmation, take profits early
- 懐疑でいる方が痛い時、それは終わりの始まり / When skepticism hurts, the end begins
